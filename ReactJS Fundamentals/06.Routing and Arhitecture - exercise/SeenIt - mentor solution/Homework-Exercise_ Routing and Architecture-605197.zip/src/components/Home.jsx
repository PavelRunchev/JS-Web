import React, { Component } from 'react';
//import '../style/submit.css';
import LoginForm from './auth/LoginForm';
import RegisterForm from './auth/RegisterForm';
import Welcome from './common/Welcome';


export default class Home extends Component {
    render = () => {
        return (
            <div className="welcome">
                <div className="signup">
                    <LoginForm />
                    <RegisterForm />
                </div>
                <Welcome />
            </div>
        )
    }
}