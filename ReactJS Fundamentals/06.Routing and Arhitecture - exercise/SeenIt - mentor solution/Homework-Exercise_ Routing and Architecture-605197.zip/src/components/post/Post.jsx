import React, { Component } from 'react';
import { withRouter, Link } from 'react-router-dom';
import requester from '../../utils/requester';
import observer from '../../utils/observer';
import calcTime from '../../utils/time';

class Post extends Component {
    constructor(props) {
        super(props);

        this.OnDeleted = this.OnDeleted.bind(this);
    }

    OnDeleted(ev) {
        let id = ev.target.attributes['data-id'].value;
        requester.remove('appdata', `posts/${id}`, 'Kinvey').then(res => {
            requester.remove('appdata', `comments?query={"postId":"${id}"}`, 'Kinvey').then(commentRes => {
                observer.trigger(observer.events.notification, {
                    type: 'success',
                    message: 'Post and all its comments deleted.'
                });
                this.props.history.push('/');
                this.props.history.push('/main');
            }).catch(err => {
                console.log(err);
            });
        }).catch(err => {
            console.log(err);
        });
    }

    render() {
        const { id, rank, url, imageUrl, title, author, time } = this.props;
        const isAuthor = author === localStorage.getItem("username");
        return (
            <article className="post">
                <div className="col rank">
                    <span>{rank}</span>
                </div>
                <div className="col thumbnail">
                    <a href={url}>
                        <img src={imageUrl} alt={title} />
                    </a>
                </div>
                <div className="post-content">
                    <div className="title">
                        <a href={url}>{title}</a>
                    </div>
                    <div className="details">
                        <div className="info">
                            submitted {calcTime(time)} ago by {author}
                        </div>
                        <div className="controls">
                            <ul>
                                <li className="action"><Link to={`/comments/${id}`}>comments</Link></li>
                                {isAuthor && <li className="action"><Link to={`/edit/${id}`} >edit</Link></li>}
                                {isAuthor && <li className="action"><a href="javascript:void(0);" data-id={id} onClick={this.OnDeleted}>delete</a></li>}
                            </ul>
                        </div>
                    </div>
                </div>
            </article>
        )
    }
}

export default withRouter(Post);