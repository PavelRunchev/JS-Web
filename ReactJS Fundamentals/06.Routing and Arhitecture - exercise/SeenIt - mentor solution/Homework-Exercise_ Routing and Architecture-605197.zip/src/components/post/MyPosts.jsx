import React, { Component } from 'react';
import Navigation from '../common/Navigation';
import Catalog from '../post/Catalog';

export default class MyPosts extends Component {
    render() {
        return (
            <div>
                <Navigation />
                <Catalog myPosts={true} />
            </div>
        )
    }
}
