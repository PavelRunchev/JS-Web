import React from 'react';
import Navigation from '../common/Navigation';
import CreatePostForm from './CreatePostForm';

const CreatePost = () => {
    return (
        <div>
            <Navigation />
            <CreatePostForm />
        </div>
    )
}

export default CreatePost;