import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import requester from '../../utils/requester';
import observer from '../../utils/observer';

class createPostForm extends Component {
    constructor(props) {
        super(props);

        this.state = {
            url: '',
            title: '',
            image: '',
            description: ''
        }

        this.onChanged = this.onChanged.bind(this);
        this.onSubmited = this.onSubmited.bind(this);
    }

    onChanged(ev) {
        this.setState({ [ev.target.name]: ev.target.value });
    }

    onSubmited(ev) {
        ev.preventDefault();

        if (this.state.url === '') {
            observer.trigger(observer.events.notification, {
                type: 'error',
                message: 'URL can not be empty.'
            });
        } else if (this.state.title === '') {
            observer.trigger(observer.events.notification, {
                type: 'error',
                message: 'Title can not be empty.'
            });
        } else if (!this.state.url.startsWith('http')) {
            observer.trigger(observer.events.notification, {
                type: 'error',
                message: 'URL is not valid link.'
            });
        } else {
            let post = {
                author: localStorage.getItem('username'),
                title: this.state.title,
                url: this.state.url,
                imageUrl: this.state.image,
                description: this.state.description
            };

            const postId = this.props.postId;

            if (postId) {
                requester.update('appdata', `posts/${postId}`, 'Kinvey', post).then(res => {
                    observer.trigger(observer.events.notification, { type: 'success', message: 'Post edited.' });
                    this.props.history.push('/main');
                }).catch(err => {
                    observer.trigger(observer.events.notification,
                        { type: 'error', message: err.responseJSON.description });
                });

                return;
            }

            requester.post('appdata', 'posts', 'Kinvey', post).then(res => {
                observer.trigger(observer.events.notification, { type: 'success', message: 'Post created.' });
                this.props.history.push('/main');
            }).catch(err => {
                observer.trigger(observer.events.notification,
                    { type: 'error', message: err.responseJSON.description });
            });
        }
    }

    componentDidMount() {
        const postId = this.props.postId;

        if (postId) {
            requester.get('appdata', `posts/${postId}`, 'Kinvey').then(res => {
                let post = {
                    url: res.url,
                    title: res.title,
                    image: res.imageUrl,
                    description: res.description
                };

                this.setState(post);
            }).catch(err => {
                console.log(err);
            });
        }
    }

    render() {
        return (
            <div>
                <div className="submitArea">
                    <h1>Create Post</h1>
                    <p>Please, fill out the form. A thumbnail image/description is not required.</p>
                    <form id="createPostFormcreatePostFormForm" className="submitForm" onSubmit={this.onSubmited}>
                        <label>Link URL:</label>
                        <input name="url" type="text" value={this.state.url} onChange={this.onChanged} />
                        <label>Link Title:</label>
                        <input name="title" type="text" value={this.state.title} onChange={this.onChanged} />
                        <label>Link Thumbnail Image (optional):</label>
                        <input name="image" type="text" value={this.state.image} onChange={this.onChanged} />
                        <label>Description (optional):</label>
                        <textarea name="description" value={this.state.description} onChange={this.onChanged}></textarea>
                        <input type="submit" value={this.props.postId ? "Edit Post" : "Create Post"} />
                    </form>
                </div>
            </div>
        )
    }
}

export default withRouter(createPostForm);