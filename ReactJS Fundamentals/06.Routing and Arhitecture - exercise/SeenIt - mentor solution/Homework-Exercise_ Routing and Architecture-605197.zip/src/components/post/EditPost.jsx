import React, { Component } from 'react';
import Navigation from '../common/Navigation';
import CreatePostForm from './CreatePostForm';

class EditPost extends Component {
    

    render() {
        let postId = this.props.match.params.id;

        return (
            <div>
                <Navigation />
                <CreatePostForm postId={postId} />
            </div>
        )
    }
}

export default EditPost;