import React, { Component } from 'react';
import { withRouter, Link } from 'react-router-dom';
import requester from '../../utils/requester';
import calcTime from '../../utils/time';

class Details extends Component {
    constructor(props) {
        super(props);

        this.OnDeleted = this.OnDeleted.bind(this);
    }

    OnDeleted(ev) {
        let id = ev.target.attributes['data-id'].value;
        requester.remove('appdata', `posts/${id}`, 'Kinvey').then(res => {
            requester.remove('appdata', `comments?query={"postId":"${id}"}`, 'Kinvey').then(commentRes => {
                this.props.history.push('/');
                this.props.history.push('/main');
            }).catch(err => {
                console.log(err);
            });
        }).catch(err => {
            console.log(err);
        });
    }

    render() {
        const { post, isAuthor } = this.props;

        return (
            <article id="postDetails" className="post">
                <div className="col thumbnail">
                    <img src={post.imageUrl} alt={post.title} />
                </div>
                <div className="post-content">
                    <div className="title">
                        <strong>{post.title}</strong>
                    </div>
                    <div className="details">
                        <div>
                            {post.description}
                        </div>
                        <div className="info">
                            submitted {calcTime(post._kmd.ect)} ago by {post.author}
                        </div>
                        <div className="controls">
                            <ul>
                                {isAuthor && <li className="action"><Link to={`/edit/${post._id}`} >edit</Link></li>}
                                {isAuthor && <li className="action"><a href="javascript:void(0);" data-id={post._id} onClick={this.OnDeleted}>delete</a></li>}
                            </ul>
                        </div>
                    </div>
                </div>
            </article>
        )
    }
}

export default withRouter(Details);