import React, { Component } from 'react';
import Post from './Post';
import requester from '../../utils/requester';

export default class Catalog extends Component {
    constructor(props) {
        super(props);

        this.state = {
            posts: [],
            isLoaded: false
        }
    }

    componentDidMount() {
        if (this.props.myPosts) {
            let username = localStorage.getItem('username');
            requester.get('appdata', `posts?query={"author":"${username}"}&sort={"_kmd.ect": -1}`, 'Kinvey').then(res => {
                this.setState({ posts: res, isLoaded: true });
            }).catch(err => {
                console.log(err);
            });
            return;
        }

        requester.get('appdata', 'posts?query={}&sort={"_kmd.ect": -1}', 'Kinvey').then(res => {
            this.setState({ posts: res, isLoaded: true });
        }).catch(err => {
            console.log(err);
        });
    }

    render() {
        if (!this.state.isLoaded) {
            return (
                <div id="loadingBox" className="notification" >
                    <span>Loading...</span>
                </div>
            )
        }

        let posts = this.state.posts || [];

        if (posts.length === 0) {
            return (
                <div>
                    <h3> No posts in database.</h3>
                </div>
            )
        }

        return (
            <div id="allForumPosts" className="posts">
                {posts.map((p, i) => {
                    return <Post
                        key={p._id}
                        id={p._id}
                        rank={i + 1}
                        url={p.url}
                        imageUrl={p.imageUrl}
                        title={p.title}
                        author={p.author}
                        time={p._kmd.ect}
                    />
                })}
            </div>
        )
    }
}