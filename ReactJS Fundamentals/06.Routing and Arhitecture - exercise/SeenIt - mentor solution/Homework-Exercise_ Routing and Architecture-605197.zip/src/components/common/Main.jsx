import React, { Component } from 'react';
import Navigation from './Navigation';
import Catalog from '../post/Catalog';

export default class Main extends Component {
    render() {
        return (
            <div>
                <Navigation />
                <Catalog />
            </div>
        )
    }
}