import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
//import '../../style/header.css';
import observer from '../../utils/observer';

class Header extends Component {
    constructor(props) {
        super(props);

        this.state = {
            username: localStorage.getItem('username') || ''
        }

        observer.subscribe(observer.events.loginUser, this.userLoggedIn);
        this.onLogout = this.onLogout.bind(this);
    }

    userLoggedIn = (username) =>
        this.setState({ username });

    // componentDidMount() {
    //     this.setState({ username: '' });
    // }

    onLogout() {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        let username = '';
        this.setState({ username });
        observer.trigger(observer.events.notification, { type: 'success', message: 'Logout successful.' });
        this.props.history.push('/');
    }


    render() {
        const loggedIn =
            <div id="profile">
                <span id="username">Hello, {this.state.username}!</span>
                |<a href="javascript:void(0);" onClick={this.onLogout}>logout</a>
            </div>
        return (
            <header>
                <span className="logo">&#9731;</span><span className="header">SeenIt</span>
                {this.state.username && loggedIn}
            </header>
        )
    }
}

export default withRouter(Header);