import React from 'react';

const Footer = () => {
    return <footer>SeenIt SPA &copy; 2018</footer>
}

export default Footer;
