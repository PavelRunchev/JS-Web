import React from 'react';
import Welcome from './Welcome';
import Navigation from './Navigation';

const About = () => {
    return (
        <div >
            <Navigation />
            <Welcome />
        </div >
    )
}
export default About;
