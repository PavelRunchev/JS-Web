import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
//import '../../style/menu.css';

export default class Navigation extends Component {
    render() {
        return (
            <div id="menu">
                <div className="title">Navigation</div>
                <NavLink className="nav" to="/main" >Catalog</NavLink>
                <NavLink className="nav" to="/createPost" >Create Post</NavLink>
                <NavLink className="nav" to="/myPosts"  >My Posts</NavLink>
                <NavLink className="nav" to="/about" >About</NavLink>
            </div>
        )
    }
}