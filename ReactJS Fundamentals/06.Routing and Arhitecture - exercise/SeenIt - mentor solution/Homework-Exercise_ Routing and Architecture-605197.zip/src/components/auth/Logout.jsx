import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import requester from '../../utils/requester';


export default class Logout extends Component {
    logout = () => {
        requester.post('user', '_logout', 'kinvey').then(res => {            
            localStorage.removeItem('token');
            localStorage.removeItem('username');
        }).catch(err => console.log(err));
    }

    render = () => {
        this.logout();
        return <Redirect to='/' />
    }
}