import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import requester from '../../utils/requester';
import observer from '../../utils/observer';

class LoginForm extends Component {
    constructor(props) {
        super(props);

        this.state = {
            username: '',
            password: ''
        }

        this.onChanged = this.onChanged.bind(this);
        this.onSubmited = this.onSubmited.bind(this);
    }

    onChanged(ev) {
        this.setState({ [ev.target.name]: ev.target.value });
    }

    onSubmited(ev) {
        ev.preventDefault();
        requester.post('user', 'login', 'basic', this.state).then(res => {
            localStorage.setItem('token', res._kmd.authtoken);
            localStorage.setItem('username', res.username);
            observer.trigger(observer.events.loginUser, res.username);
            observer.trigger(observer.events.notification, { type: 'success', message: 'Login successful.' });
            this.setState({ username: '', password: '' });
            this.props.history.push('/main');
        }).catch(err => {
            //console.log(err);
            observer.trigger(observer.events.notification,
                { type: 'error', message: err.responseJSON.description });
        });
    }

    render() {

        return (
            <div>
                <form id="loginForm" onSubmit={this.onSubmited}>
                    <h2>Sign In</h2>
                    <label>Username:</label>
                    <input name="username" type="text" value={this.state.username} onChange={this.onChanged} />
                    <label>Password:</label>
                    <input name="password" type="password" value={this.state.password} onChange={this.onChanged} />
                    <input id="btnLogin" type="submit" value="Sign In" />
                </form>
            </div>
        )
    }
}

export default withRouter(LoginForm);