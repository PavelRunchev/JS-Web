import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import requester from '../../utils/requester';
import observer from '../../utils/observer';

class RegisterForm extends Component {
    constructor(props) {
        super(props);

        this.state = {
            username: '',
            password: '',
            repeatPass: ''
        }

        this.onChanged = this.onChanged.bind(this);
        this.onSubmited = this.onSubmited.bind(this);
    }

    onChanged(ev) {
        this.setState({ [ev.target.name]: ev.target.value });
    }

    onSubmited(ev) {
        ev.preventDefault();

        if (!/^[A-Za-z]{3,}$/.test(this.state.username)) {
            observer.trigger(observer.events.notification, {
                type: 'error',
                message: 'A username should be at least 3 characters long and should contain only english alphabet letters.'
            });
        } else if (!/^[A-Za-z0-9]{6,}$/.test(this.state.password)) {
            observer.trigger(observer.events.notification, {
                type: 'error',
                message: 'A user‘s password should be at least 6 characters long and should contain only english alphabet letters and digits.'
            });
        } else if (this.state.password !== this.state.repeatPass) {
            observer.trigger(observer.events.notification, {
                type: 'error',
                message: 'Both passwords should match.'
            });
        } else {
            requester.post('user', '', 'basic', { username: this.state.username, password: this.state.password }).then(res => {
                localStorage.setItem('token', res._kmd.authtoken);
                localStorage.setItem('username', res.username);
                observer.trigger(observer.events.loginUser, res.username);
                observer.trigger(observer.events.notification, { type: 'success', message: 'Register successful.' });
                this.setState({ username: '', password: '', repeatPass: '' });
                this.props.history.push('/main');
            }).catch(err => {
                observer.trigger(observer.events.notification,
                    { type: 'error', message: err.responseJSON.description });
            });
        }
    }

    render() {
        return (
            <div>
                <form id="registerForm" onSubmit={this.onSubmited}>
                    <h2>Register</h2>
                    <label>Username:</label>
                    <input name="username" type="text" value={this.state.username} onChange={this.onChanged} />
                    <label>Password:</label>
                    <input name="password" type="password" value={this.state.password} onChange={this.onChanged} />
                    <label>Repeat Password:</label>
                    <input name="repeatPass" type="password" value={this.state.repeatPass} onChange={this.onChanged} />
                    <input id="btnRegister" type="submit" value="Sign Up" />
                </form>
            </div>
        )
    }
}

export default withRouter(RegisterForm);


// if (!/^[A-Za-z]{3,}$/.test(username)) {
//     auth.showError('A username should be at least 3 characters' +
//         ' long and should contain only english alphabet letters.');
// } else if (!/^[A-Za-z0-9]{6,}$/.test(password)) {
//     auth.showError('A user‘s password should be at least 6 characters long' +
//         ' and should contain only english alphabet letters and digits.');
// } else if (password !== repeatPassword) {
//     auth.showError('Both passwords should match.');
// } else {
//     auth.register(username, password)
//         .then(function (userData) {
//             auth.saveSession(userData);
//             auth.showInfo('User registration successful.');
//             //TODO load catalog
//             ctx.redirect('#/catalog');
//         })
//         .catch(auth.handleError);
// }