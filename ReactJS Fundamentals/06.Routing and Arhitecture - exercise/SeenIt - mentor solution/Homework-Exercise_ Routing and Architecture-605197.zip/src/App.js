import React, { Component } from 'react';
import { Route, Switch, withRouter } from 'react-router-dom';
import './App.css';
//import './style/site.css';

import Header from './components/common/Header';
import Notification from './components/common/Notification';
import Footer from './components/common/Footer';
import Home from './components/Home';
import Main from './components/common/Main';
import CreatePost from './components/post/CreatePost';
import About from './components/common/About';
import Comments from './components/comment/Comments';
import MyPosts from './components/post/MyPosts';
import EditPost from './components/post/EditPost';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header />
        <main className="content">
          <Notification />
          <Switch>
            <Route path='/' exact component={Home} />
            <Route path='/main' component={Main} />
            <Route path='/createPost' component={CreatePost} />
            <Route path='/myPosts' component={MyPosts} />
            <Route path='/about' component={About} />
            <Route path='/comments/:id' component={Comments} />
            <Route path='/edit/:id' component={EditPost} />

          </Switch>
        </main>
        <Footer />
      </div>
    );
  }
}

export default withRouter(App);
